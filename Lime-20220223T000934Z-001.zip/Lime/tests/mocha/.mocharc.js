'use strict';

module.exports = {
  ui: 'tdd',
  file: '../blockly_uncompressed.js',
  reporter: 'landing'
};
