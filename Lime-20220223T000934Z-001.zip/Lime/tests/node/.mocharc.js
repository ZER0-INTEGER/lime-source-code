'use strict';

module.exports = {
  ui: 'tdd',
  reporter: 'landing'
};
