# Zelos Rendering / PXT-Blockly Comparison Playground

## Dependencies
```
npm install -g http-server
```

## Running the Playground:

In Blockly's root directory, run:
```
http-server ./
```

and browse to:
```
http://127.0.0.1:8080/tests/rendering/zelos
```

